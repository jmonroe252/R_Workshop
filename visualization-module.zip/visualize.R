iris <- read.csv("/Users/deepak/courses/R-workshop/iris-1.csv")
head(data)
library(ggplot2)
#histogram
dplt <- ggplot(iris,aes(x=sepal.length))
dplt+geom_histogram()
dplt+geom_histogram(binwidth=1)
dplt+geom_histogram(bins=100)
dplt + geom_histogram(color="black",fill="blue",bins=10)

#Box Plot
dplt <- ggplot(iris, aes(species,sepal.width))
dplt+geom_boxplot()
dplt <- ggplot(iris, aes(species,sepal.width,color=species))
dplt+geom_boxplot()
dplt+geom_boxplot()+geom_jitter()

#outliers
outl<-read.csv("/Users/deepak/courses/R-workshop/outliers.csv")
h <- ggplot(outl, aes(Class,Feature.0,color=Class))
h+geom_boxplot()+geom_jitter()

#grouping
groups<-read.csv("/Users/deepak/courses/R-workshop/groups.csv")
h <- ggplot(groups, aes(factor(Class),Feature.0,color=Class))
h+geom_boxplot()+geom_jitter()

#line-plot
climate<-read.csv("/Users/deepak/courses/R-workshop/climate.csv")
ggplot(climate,aes(Year,Anomaly10y)) + geom_line()

#line-plot with confidence
ggplot(climate, aes(Year, Anomaly10y)) + geom_ribbon(aes(ymin = Anomaly10y - Unc10y, ymax = Anomaly10y +Unc10y), fill = "blue", alpha = .1) + geom_line(color = "steelblue")



#bar-chart
ggplot(iris, aes(species, sepal.length)) + geom_bar(stat = "identity")
library(reshape2)
df <- melt(iris, id.vars = "species")
ggplot(df, aes(species, value, fill = variable)) +geom_bar(stat="identity")
ggplot(df, aes(species, value, fill = variable)) +geom_bar(stat="identity",position="dodge")

#bar-char with extra variable
climate['sign']= (climate$Anomaly10y > 0)
ggplot(climate,aes(Year,Anomaly10y,stat="identity"))+geom_bar()
ggplot(climate,aes(Year,Anomaly10y,fill=sign))+geom_bar(stat="identity")

#scatter plot
ggplot(data = iris, aes(x = sepal.length, y = sepal.width)) + geom_point(size=3)
ggplot(data = iris, aes(x = sepal.length, y = sepal.width,color=species)) + geom_point(size=3)
ggplot(data = iris, aes(x = sepal.length, y = sepal.width,color=species)) + geom_point(aes(shape=species),size=3)

#density plot
ggplot(iris,aes(x=sepal.length))+geom_density()
ggplot(iris,aes(x=sepal.width))+geom_density(fill="blue",alpha=0.7)

#Facet
ggplot(iris, aes(sepal.length, sepal.width, color = species)) + geom_point() +facet_grid(species~.) 
ggplot(iris, aes(sepal.length, sepal.width, color = species)) + geom_point() +facet_grid(.~species) 
ggplot(iris, aes(sepal.length, sepal.width, color = species)) + geom_point() +facet_wrap(~ species) 
fct<-read.csv("/Users/deepak/courses/R-workshop/tips.csv")
ggplot(fct, aes(total_bill, tip, color = sex)) + geom_point() +facet_grid(.~sex) 
ggplot(fct, aes(total_bill, tip, color = sex)) + geom_point() +facet_grid(time ~ sex) 


#fitting
ggplot(iris, aes(sepal.length, sepal.width, color = species)) + geom_point(aes(shape = species), size = 3) + geom_smooth(method = "lm") 
ggplot(iris, aes(sepal.length, sepal.width, color = species)) + geom_point(aes(shape = species), size = 3) + geom_smooth() +facet_wrap(~species) 
ggplot(fct, aes(total_bill, tip, color = sex)) + geom_point() +facet_grid(time ~ sex) + geom_smooth(method = "lm") 

#Scaling
ggplot(fct, aes(size,total_bill, color = sex))+geom_point()+scale_x_discrete("Size-x",breaks=c(1,2,3,4,5,6),labels=c("one","two","three","four","five","six"))
ggplot(fct, aes(size,total_bill, color = sex))+geom_point()+scale_y_log10()
rev = read.csv("/Users/deepak/courses/R-workshop/reviews.csv")
ggplot(rev,aes(Feature.0))+geom_histogram()+scale_y_log10()+scale_x_log10()

#Colors
library(RColorBrewer) 
display.brewer.all() 
df <- melt(iris, id.vars = "species") 
ggplot(df, aes(species, value, fill = variable)) + geom_bar(stat = "identity", position = "dodge") + scale_fill_brewer(palette = "Set2") 
ggplot(iris, aes(sepal.length, sepal.width, color = species)) + geom_point() + facet_grid(species ~ .) + scale_color_manual(values = c("red", "green", "blue"))


#credit card
crdt = read.csv("/Users/deepak/courses/R-workshop/credit.csv")
head(crdt)
ggplot(crdt,aes(income))+geom_density()+scale_y_log10()
ggplot(crdt,aes(default,income))+geom_boxplot()+geom_jitter()
ggplot(crdt,aes(income,balance))+geom_point()
ggplot(crdt,aes(income,balance))+geom_point()+facet_grid(student~.)
ggplot(crdt,aes(income,balance,color=default))+geom_point()+facet_grid(student~default)

#Weather
weather = read.csv("/Users/deepak/courses/R-workshop/weather_2012.csv")
head(weather)
#df<-melt(weather,id.vars="Date.Time")
#ggplot(weather,aes(x=Weather))+geom_point(aes(y=Visibility))
#ggplot(weather,aes(x=Weather))+geom_point(aes(y=Visibility))
library(scales)
#weather$date <- factor(as.Date(weather$Date.Time))
#head(weather)
ggplot(weather,aes(x=factor(as.Date(weather$Date.Time)),y=Temp))+stat_summary(fun.y="mean",geom="bar")


#Movies
movies = read.csv("/Users/deepak/courses/R-workshop/ratings.csv")
#head(movies)
ggplot(movies,aes(x=Rating))+geom_histogram()
ggplot(movies,aes(x=Rating))+geom_histogram()+facet_grid(.~Gender)
ggplot(movies,aes(x=factor(Genre),y=Rating))+stat_summary(fun.y="mean",geom="bar")
ggplot(movies,aes(x=factor(Genre),y=Rating,color=Occupation))+stat_summary(fun.y="mean",geom="point")+facet_grid(Gender~.)
ggplot(movies,aes(x=factor(Age),y=Rating,color=Gender))+stat_summary(fun.y="mean",geom="point")+facet_grid(Occupation~Gender)
movies$bins <- cut(movies$Age, breaks=seq(0, 81, by=20), labels=c("young","adult","middle","senior"))
#head(movies)
ggplot(movies,aes(x=factor(bins),y=Rating,color=Gender))+stat_summary(fun.y="mean",geom="point")+facet_grid(Occupation~Gender)
