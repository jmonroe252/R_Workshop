 #K-Nearest Neighbor
 df <- read.csv("C:\\Users\\dkesha\\Research\\datascience\\R-workshop\\german.data-numeric.csv",header=TRUE)
 head(df)
 summary(df)
library(caret) 
 #Standardization
 pre<- preProcess(df[,-25], method=c('center', 'scale'))
 df = predict(pre,df)
 #Train-Test split
 trainIndex <- createDataPartition(df$C, p=0.8, list=FALSE)
 data_train <- df[ trainIndex,]
 data_test <- df[ -trainIndex,]
 #Run the classifier
 library(class)
 df_pred <- knn(train = data_train[,-25], test = data_test[,-25], cl = data_train$C, k=3)
 which(df_pred!=data_test$C)
 all.equal(df_pred,data_test$C)
 library(gmodels)
 CrossTable(df_pred,data_test$C)
 
 #Cross-validation
 train_control <- trainControl(method="cv", number=10)
 model <- train(C~., data=df, trControl=train_control, method="knn")
 
 
 #Tune the parameters
 grid <- expand.grid(k=c(1,3,5,10))
 model <- train(C~., data=df, trControl=train_control, method="knn",tuneGrid=grid)
 control <- trainControl(method="repeatedcv", number=10, repeats=3)

#Linearly-separable dataset
df <- read.csv("C:\\Users\\dkesha\\Research\\datascience\\R-workshop\\dataset-lin.csv",header=TRUE)
plot(df$D.0, df$D.1, pch=21, bg=c("red","green3")[unclass(df$C)])
trainIndex <- createDataPartition(df$C, p=0.8, list=FALSE)
lin_data_train <- df[ trainIndex,]
lin_data_test <- df[ -trainIndex,]
#Logistic Regression
mod_fit <- train(C ~ ., data=lin_data_train, method="glm", family="binomial")
mod_fit
summary(mod_fit)
#Treshold the output
predict1 <- predict(mod_fit, lin_data_test,type = 'prob') 
predict1 <- ifelse(predict1 > 0.5,1,0)
predict1

#Nor linearly seperable dataset
df <- read.csv("C:\\Users\\dkesha\\Research\\datascience\\R-workshop\\dataset-nlin.csv",header=TRUE)
plot(df$D.0, df$D.1, pch=21, bg=c("red","green3")[unclass(df$C)], main="Data Plot")
trainIndex <- createDataPartition(df$C, p=0.8, list=FALSE)
nlin_data_train <- df[ trainIndex,]
nlin_data_test <- df[ -trainIndex,]
mod_fit <- train(C ~ ., data=nlin_data_train, method="glm", family="binomial")
mod_fit

train_control <- trainControl(method="cv", number=10)
model <- train(C~., data=df, trControl=train_control, method="glm")

#Precision/Recall curves and ROC Curves
library(ROCR)
predict1 <- predict(mod_fit, nlin_data_test,type = 'raw') 
truevals <- ifelse(nlin_data_test$C=="Good",1,0)
predvals <- ifelse(predict1=="Good",1,0)
pred <- prediction(predvals, truevals);
pr = performance(pred, "prec", "rec"); 
plot(pr)
ROCRpred <- prediction(predvals, truevals)
ROCRperf <- performance(ROCRpred, 'tpr','fpr')
plot(ROCRperf, colorize = TRUE, text.adj = c(-0.2,1.7))
confusionMatrix(predvals,truevals)
#ROC-Area under the curve Score
auc <- performance(pred, measure = "auc")
auc <- auc@y.values[[1]]



#Clearly demarcated clusters
df <- read.csv("C:\\Users\\dkesha\\Research\\datascience\\R-workshop\\dataset-km-1.csv",header=TRUE)

pre<- preProcess(df, method=c('center', 'scale'))
df = predict(pre,df)
plot(df$F1, df$F2, pch=21)
#Fit 4 clusters using K-Means
set.seed(1234)
kmeansfit = kmeans(df,4)
kmeansfit$cluster
plot(df$F1, df$F2, pch=21, bg=c("red","green3","black","yellow")[unclass(kmeansfit$cluster)], main="Data Plot")

#Tune the value of K
library(NbClust)
nc <- NbClust(df, min.nc=2, max.nc=8, method="kmeans")
table(nc$Best.n[1,])
#Tune the value using a single clustering metric (gap)
nc <- NbClust(df, min.nc=2, max.nc=15, method="kmeans",index="gap")

#Non clearly demarcated clusters
df <- read.csv("C:\\Users\\dkesha\\Research\\datascience\\R-workshop\\dataset-km-2.csv",header=TRUE)
pre<- preProcess(df, method=c('center', 'scale'))
df = predict(pre,df)
plot(df$F1, df$F2, pch=21)
set.seed(1234)
kmeansfit = kmeans(df,6)
kmeansfit$cluster
plot(df$F1, df$F2, pch=21, bg=c("red","green3","black","yellow")[unclass(kmeansfit$cluster)], main="Data Plot")
